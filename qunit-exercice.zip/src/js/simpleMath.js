SimpleMath = function (){
	// TODO
};

SimpleMath.prototype.getFactorial = function (n){
	// TODO
	if(n<0){
		throw new Error ("There is no factorial for negative number");
	}else {
		//return (n==1)?1:n*this.getFactorial(n-1);
	}
};

SimpleMath.prototype.signum = function (){
	// TODO
};

SimpleMath.prototype.average = function (){
	// TODO
};